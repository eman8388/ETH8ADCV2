//------------------------------------------------------------------------
// Copyright(c) 2025 eugeniomancini.
//------------------------------------------------------------------------

#pragma once

#include "public.sdk/source/vst/vstaudioeffect.h"

#include "params.h"
#include "adc.h"

namespace MyCompanyName {

//------------------------------------------------------------------------
//  ETH8ADCV2Processor
//------------------------------------------------------------------------
class ETH8ADCV2Processor : public Steinberg::Vst::AudioEffect
{
public:
	ETH8ADCV2Processor ();
	~ETH8ADCV2Processor () SMTG_OVERRIDE;

    // Create function
	static Steinberg::FUnknown* createInstance (void* /*context*/) 
	{ 
		return (Steinberg::Vst::IAudioProcessor*)new ETH8ADCV2Processor; 
	}

	//--- ---------------------------------------------------------------------
	// AudioEffect overrides:
	//--- ---------------------------------------------------------------------
	/** Called at first after constructor */
	Steinberg::tresult PLUGIN_API initialize (Steinberg::FUnknown* context) SMTG_OVERRIDE;
	
	/** Called at the end before destructor */
	Steinberg::tresult PLUGIN_API terminate () SMTG_OVERRIDE;
	
	/** Switch the Plug-in on/off */
	Steinberg::tresult PLUGIN_API setActive (Steinberg::TBool state) SMTG_OVERRIDE;

	/** Will be called before any process call */
	Steinberg::tresult PLUGIN_API setupProcessing (Steinberg::Vst::ProcessSetup& newSetup) SMTG_OVERRIDE;
	
	/** Asks if a given sample size is supported see SymbolicSampleSizes. */
	Steinberg::tresult PLUGIN_API canProcessSampleSize (Steinberg::int32 symbolicSampleSize) SMTG_OVERRIDE;

	/** Here we go...the process call */
	Steinberg::tresult PLUGIN_API process (Steinberg::Vst::ProcessData& data) SMTG_OVERRIDE;
		
    //correct the bus arrangement
    Steinberg::tresult PLUGIN_API setBusArrangements(Steinberg::Vst::SpeakerArrangement* inputs, Steinberg::int32 numIns, Steinberg::Vst::SpeakerArrangement* outputs, Steinberg::int32 numOuts) SMTG_OVERRIDE;
    
	/** For persistence */
	Steinberg::tresult PLUGIN_API setState (Steinberg::IBStream* state) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API getState (Steinberg::IBStream* state) SMTG_OVERRIDE;

//------------------------------------------------------------------------
protected:
    ETHlink* ethlink=NULL;
    
    uint16_t sn = 0;
    int interface_index = 0;
    int delay=8;
    bool bypass = 0;
    bool c = 0;

    float* in1;
    float* in2;
    float* in3;
    float* in4;
    float* in5;
    float* in6;
    float* in7;
    float* in8;
    float* out1;
    float* out2;
    float* out3;
    float* out4;
    float* out5;
    float* out6;
    float* out7;
    float* out8;

    uint8_t g1 = 0;
    uint8_t g2 = 0;
    uint8_t g3 = 0;
    uint8_t g4 = 0;
    uint8_t g5 = 0;
    uint8_t g6 = 0;
    uint8_t g7 = 0;
    uint8_t g8 = 0;
    bool m1 = 0;
    bool m2 = 0;
    bool m3 = 0;
    bool m4 = 0;
    bool m5 = 0;
    bool m6 = 0;
    bool m7 = 0;
    bool m8 = 0;
    bool ph1 = 0;
    bool ph2 = 0;

    bool pass = 0;

    bool s = 0;
    float p1 = 0;
    float p2 = 0;
    float p3 = 0;
    float p4 = 0;
    float p5 = 0;
    float p6 = 0;
    float p7 = 0;
    float p8 = 0;

    float max1 = 0;
    float max2 = 0;
    float max3 = 0;
    float max4 = 0;
    float max5 = 0;
    float max6 = 0;
    float max7 = 0;
    float max8 = 0;

    double t1 = 0;
    double t2 = 0;
    
    uint32_t FS = 48000;
    uint8_t FSc = 1;
    int sampleN = 0;
    
 
    int32_t obuff[16384] = { 0 };
    //constant
    const float INV_MAX_INT32 = 1.0f / 2147483648.0f; // Calculate once
};

//------------------------------------------------------------------------
} // namespace MyCompanyName
