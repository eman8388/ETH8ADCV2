//------------------------------------------------------------------------
// Copyright(c) 2025 eugeniomancini.
//------------------------------------------------------------------------

#pragma once

#include "pluginterfaces/base/funknown.h"
#include "pluginterfaces/vst/vsttypes.h"

namespace MyCompanyName {
//------------------------------------------------------------------------
static const Steinberg::FUID kETH8ADCV2ProcessorUID (0x2A19A7BC, 0x9A70533F, 0xA145425C, 0x7A60A7CA);
static const Steinberg::FUID kETH8ADCV2ControllerUID (0xA23FD5F6, 0xD9515E04, 0x828E67AD, 0x700B07FB);

#define ETH8ADCV2VST3Category "Fx"

//------------------------------------------------------------------------
} // namespace MyCompanyName
